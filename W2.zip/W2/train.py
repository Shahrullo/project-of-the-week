import os
import pickle
import click

from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error

import mlflow

def load_pickle(filename: str):
    with open(filename, "rb") as f_in:
        return pickle.load(f_in)


@click.command()
@click.option(
    "--data_path",
    default="./output",
    help="Location where the processed NYC taxi data was saved'"
)

def run_train(data_path: str):

    mlflow.start_run() # Start an MLflow run

    X_train, y_train = load_pickle(os.path.join(data_path, "train.pkl"))
    X_val, y_val = load_pickle(os.path.join(data_path, "val.pkl"))

    # Enable MLflow autologging
    mlflow.sklearn.autolog()

    rf = RandomForestRegressor(max_depth=10, random_state=0)
    rf.fit(X_train, y_train)
    y_pred = rf.predict(X_val)

    rmse = mean_squared_error(y_val, y_pred, squared=False)

    # Log the RMSE metrics and the random forest model
    mlflow.log_metric("rmse", rmse)
    mlflow.sklearn.log_model(rf, "random_forest_model")

    mlflow.end_run() # End the MLflow run


if __name__ == "__main__":
    run_train()
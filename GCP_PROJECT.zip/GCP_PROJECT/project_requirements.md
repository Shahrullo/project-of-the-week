EASY PROJECT IF YOU KNOW GCP ML – SIMPLE ML CODE I GIVE YOU, YOU ONLY ASKED HOW TO DEPLOY

I give you base code and data or you can use your code and data if I like it

1. ML project end to end development on Google GCP
2. Any python package installed by pip potentially can be used for this ML project – fully customised ML project capability
3. Build with Automatic scaling a customized model training for python code ML model provided by me
4. Build with Automatic scaling a customized inference -  as more request as more VMs used and as less request as less VMs used (fast VMs number adjustment ). Fast change of VMs number for fast load change ( 1 second adjustment speed)
5. Automatic scaling, load balancing to handle 100,000 requests/sec, requests done in parallel  by python from any many computer on web
6. many VMs Distributed ML model Training with Hyperparameters search, Grid Search on many VMs (for example, 1000 hyperparameter sets with 5 VMs in VertixAI, each machine will calculate 200 parameters)
7. many VMs Distributed Preprocessing (optional)
8. many VMs Distributed Inference
9. requests implemented by python running on windows and linux computer. Predictions may be done from any computer on web no credentials needed (not ssh or any remote connection to GCP with credentials)
10. no GUI design, but all done by python SDK
11. basic ML code and data will be provided
12. implement one good VM solution as well and compare cost and performance  for many small VMs vs one good Vm
13. do not use Flask, but use FastAPI
YOU PROVIDE PYTHON CODE for GCP  AND
VIDEO (my guess it will be around  60 minutes video) WITH EXPLANATIONS STEP BY STEP HOW TO DO
---------------------------------------------------------------
PROJECT ACCEPTANCE : I CAN DO BY MYSELF on my GCP  account
----------------------------------------------------------------
TIME MAX 1 WEEK
=====================================================
Testing :
0. Do local computer prediction
1 For cloud prediction I use your python code which hosted on my GCP cloud project created by me using your instructions.
2 Make sure there are no dropped requests. Test in python code for requests if there are requests without correct response (calculate prediction for request locally and then compare with returned from GCP   )
3 Many requests are sent in parallel from different computers: REQUEST consists of  unique ID and textual  data
4 Response: the same unique ID and prediction from ML model, ML model adds suffix done for ID. For example, ID: abc123 will returned abc123done
5 When predictions are received: unique returned ID is used to match ID from  GCP prediction and request text data local prediction.
ID to confirm it is the same request text used on GCP  what was sent for prediction
6 compare local and remote prediction, calculate how many are the same

***************************************************************************
I do not give you access to my GCP  account
make development on your GCP  account

# What will be done
0. Check GCP VertexAI vs Kubernetes
1. Project will be done with Kubernetes in GCP (will use GCP LoadBalancer)
2. No dropped request even for very fast (from 10 - 100,000 request during in one second), need to simulate this kind of traffic from many local computers
3. Have to do the API in Docker images

## Steps
1. Create API with FastAPI in Docker images locally
2. Test with Kubernetes locally (minikube)
3. Locally test with 1,000 request (estimation) (see option of simulation) (use connected computers with the same WiFi)
4. Create Kubernetes Engine and other necessary tools in GCP (IMU, etc.)
5. Upload Docker image to the GCP container
6. Base VM on the GCP is low cost - 2CPU and 4GB RAM (choose)
7. Simulate ML model complexity by using delays (sleep python function in the main training code)
8. Writing .yaml file for Kubernetes actions
9. Monitoring for Kubernetes operation, especially upscaling and downscaling timeline
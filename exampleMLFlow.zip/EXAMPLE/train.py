#!/usr/bin/env python
# coding: utf-8

import os
import json
import joblib
import numpy as np
import pandas as pd
import mlflow
import mlflow.sklearn
from mlflow.models import ModelSignature
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OrdinalEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

# Initialize MLflow
MLFLOW_TRACKING_URI = "http://localhost:5000"
mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)  # Set your MLflow server URI

def main():
    # Load the dataset
    data = pd.read_csv("data/healthcare-dataset-stroke-data.csv")
    
    # Prepare data
    X, y = prepare_data(data)
    
    # Create and train the pipeline
    pipeline = create_pipeline()
    
    # Evaluate the model using k-fold cross-validation
    k_fold = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    scores = []

    for fold, (train_idx, test_idx) in enumerate(k_fold.split(X, y)):
        X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
        y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

        with mlflow.start_run() as run:
            mlflow.log_params(pipeline.named_steps['model'].get_params())  # Log model hyperparameters
            mlflow.log_params({"data_preprocessing": "simple_imputer_mean"})
            mlflow.set_tags({"model_type": "DecisionTreeClassifier"})
            
            # Fit the pipeline on the training data
            pipeline.fit(X_train, y_train)
            
            # Make predictions on the test set
            y_pred = pipeline.predict(X_test)
            
            # Calculate and log accuracy
            accuracy = accuracy_score(y_test, y_pred)
            mlflow.log_metrics({"fold_accuracy": accuracy})
            
            # Save the trained pipeline as an artifact
            pipeline_filename = "stroke_prediction_pipeline_fold_{}.pkl".format(fold)
            joblib.dump(pipeline, pipeline_filename)  # Save the pipeline locally
            
            # Log the artifact directory containing the model and other artifacts
            mlflow.log_artifacts("artifacts", artifact_path="artifacts/fold_{}".format(fold))
            
            
            # Define input and output schema and log them
            input_schema = json.dumps(
                [
                    {"name": "age", "type": "double"},
                    {"name": "hypertension", "type": "integer"},
                    {"name": "heart_disease", "type": "integer"},
                    {"name": "avg_glucose_level", "type": "double"},
                    {"name": "bmi", "type": "double"},
                    {"name": "gender", "type": "string"},
                    {"name": "ever_married", "type": "string"},
                    {"name": "work_type", "type": "string"},
                    {"name": "Residence_type", "type": "string"},
                    {"name": "smoking_status", "type": "string"}
                ]
            )
            output_schema = json.dumps(
                [
                    {"name": "prediction", "type": "double"}
                ]
            )
            
            signature = ModelSignature.from_dict({'inputs': input_schema, 'outputs': output_schema})
            mlflow.sklearn.log_model(pipeline, 
                                     artifact_path="models/fold_{}".format(fold), input_example=X_train.head(1), 
                                     signature=signature)
            
            # Append the fold accuracy to the list of scores
            scores.append(accuracy)

    # Log cross-validation metrics to MLflow
    with mlflow.start_run() as run:
        mlflow.log_metrics({"mean_accuracy": np.mean(scores)})
        mlflow.log_metrics({"std_accuracy": np.std(scores)})

    print("Cross-Validation Scores:", scores)
    print(f"Mean Accuracy: {np.mean(scores):.2f} (+/- {np.std(scores) * 2:.2f})")

    # Register the model in the Model Registry
    model_uri = f"runs:/{run.info.run_id}/models"
    mlflow.register_model(model_uri, "StrokePredictionModel")

def prepare_data(data):
    # Clean up column names
    data.columns = data.columns.str.strip()

    # Select features and target
    X = data[data.columns.difference(['stroke'])]
    y = data['stroke']

    return X, y

def create_data_preprocessor():
    # Select categorical and numerical columns
    numerical_columns = ['age', 'hypertension', 'heart_disease', 'avg_glucose_level', 'bmi']
    categorical_columns = ['gender', 'ever_married', 'work_type', 'Residence_type', 'smoking_status']

    # Preprocessing pipeline for numerical features
    numerical_processor = SimpleImputer(strategy="mean")  # Fill missing values with mean

    # Preprocessing pipeline for categorical features
    categorical_processor = Pipeline(steps=[
        ('ordinal_encoder', OrdinalEncoder(dtype=np.int64,
                                           handle_unknown='use_encoded_value',
                                           unknown_value=-1)),
    ])

    # Combine the numerical and categorical processors using ColumnTransformer
    preprocessor = ColumnTransformer(
        transformers=[
            ('categorical_processor', categorical_processor, categorical_columns),
            ('passthrough', numerical_processor, numerical_columns),
        ],
        remainder='drop', verbose_feature_names_out=False)
    return preprocessor

def create_pipeline():
    # Create a pipeline with preprocessing and model
    preprocessor = create_data_preprocessor()
    pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('model', DecisionTreeClassifier(random_state=42))
    ])
    return pipeline

if __name__ == "__main__":
    main()
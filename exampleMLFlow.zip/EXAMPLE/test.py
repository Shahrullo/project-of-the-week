# import mlflow.pyfunc
# import pandas as pd
# import numpy as np

# # Specify the registered model name and version (you can find these values in your MLflow Model Registry)
# model_name = "StrokePredictionModel"
# model_version = "2"  # Replace with the specific version you want to use

# # Load the registered model
# model = mlflow.pyfunc.load_model(model_uri=f"models:/{model_name}/{model_version}")

# # Generate some random test data for prediction
# test_data = pd.DataFrame({
#     'age': [45, 55, 65],
#     'hypertension': [1, 0, 1],
#     'heart_disease': [0, 1, 0],
#     'avg_glucose_level': [100, 120, 80],
#     'bmi': [28, 32, 25],
#     'gender': ['Male', 'Female', 'Male'],
#     'ever_married': ['Yes', 'Yes', 'No'],
#     'work_type': ['Private', 'Self-employed', 'Govt_job'],
#     'Residence_type': ['Urban', 'Rural', 'Urban'],
#     'smoking_status': ['formerly smoked', 'never smoked', 'Unknown']
# })

# # Make predictions using the loaded model
# predictions = model.predict(test_data)

# # Display the predictions
# print("Predictions:")
# print(predictions)

import mlflow.pyfunc
import pandas as pd

# Generate some random test data for prediction
test_data = pd.DataFrame({
    'age': [45, 55, 65],
    'hypertension': [1, 0, 1],
    'heart_disease': [0, 1, 0],
    'avg_glucose_level': [100, 120, 80],
    'bmi': [28, 32, 25],
    'gender': ['Male', 'Female', 'Male'],
    'ever_married': ['Yes', 'Yes', 'No'],
    'work_type': ['Private', 'Self-employed', 'Govt_job'],
    'Residence_type': ['Urban', 'Rural', 'Urban'],
    'smoking_status': ['formerly smoked', 'never smoked', 'Unknown']
})

import mlflow.pyfunc

model_name = "StrokePredictionModel"
model_version = 1

model = mlflow.pyfunc.load_model(model_uri=f"models:/{model_name}/{model_version}")

predictions = model.predict(test_data)


# import mlflow
# logged_model = 'runs:/5a05c49a90aa4680851d38d2ac6bea19/models/fold_4'

# # Load model as a PyFuncModel.
# loaded_model = mlflow.pyfunc.load_model(logged_model)

# # Predict on a Pandas DataFrame.
# predictions = loaded_model.predict(pd.DataFrame(test_data))

# Display the predictions
print("Predictions:")
print(predictions)


# "Managing the ML Lifecycle: A Practical Guide with a Stroke Prediction Example"

example: https://www.clearpeaks.com/end-to-end-mlops-using-mlflow/
		 https://medium.com/@ilaslanduzgun/how-to-serve-machine-learning-model-using-fastapi-mlflow-minio-mysql-8b99a6c76989

## Introduction

In our previous articles, we explored the power of MLflow in streamlining the machine learning lifecycle and set up a robust environment with Docker Compose, Minio, and PostgreSQL. Now, let's dive into a real-world example to understand how to manage the entire machine learning lifecycle using MLflow. We'll use a dataset from Kaggle and build a machine learning model to predict stroke occurrences. This practical guide will walk you through data preparation, model training, tracking experiments, and deploying the model—all within the MLflow ecosystem.

### Prerequisites

Before we begin, ensure that you have MLflow installed in your Python environment. You can install it via pip. It is recommended to install dependencies in virtual environment. You can use pip, conda, pipenv, or poetry:

```bash
pip install mlflow
```

You should also have Docker Compose, Minio, and PostgreSQL set up, as described in our previous article.

### Step 1: Data Preparation

1. **Download the Dataset**: We'll be using the "healthcare-dataset-stroke-data.csv" dataset from Kaggle, which contains features related to health parameters and stroke occurrences.

2. **Data Exploration and Preprocessing**: Load the dataset, explore its structure, handle missing values, encode categorical variables, and split the data into training and testing sets.

### Step 2: Model Training

For this example, let's use a simple decision tree classifier:

```python
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
import mlflow
import mlflow.sklearn

# Load the preprocessed data
data = pd.read_csv('preprocessed_data.csv')

# Split the data into features and target
X = data.drop('stroke', axis=1)
y = data['stroke']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create and train the decision tree classifier
with mlflow.start_run():
    clf = DecisionTreeClassifier()
    clf.fit(X_train, y_train)

    # Make predictions
    y_pred = clf.predict(X_test)

    # Calculate accuracy
    accuracy = accuracy_score(y_test, y_pred)

    # Log parameters and metrics to MLflow
    mlflow.log_params({'max_depth': clf.get_params()['max_depth']})
    mlflow.log_metric('accuracy', accuracy)

    # Save the model
    mlflow.sklearn.save_model(clf, 'decision_tree_model')
```

### Step 3: Experiment Tracking

MLflow allows us to easily track our experiments and store relevant information. To view and manage experiments, use the MLflow web UI at `http://localhost:5000`.

### Step 4: Model Deployment

1. **Register the Model**: In the MLflow web UI, navigate to the 'Models' tab and register the 'decision_tree_model' we trained earlier.

2. **Deploy the Model**: Deploy the registered model to your production environment. You can use various deployment options, such as REST APIs, Docker containers, or cloud platforms.

Conclusion

In this article, we've demonstrated the end-to-end machine learning lifecycle management using MLflow with a practical example of stroke prediction. Starting with data preparation, we built and trained a machine learning model, tracked our experiments, and deployed the model for real-world use.

MLflow's powerful capabilities make it an invaluable tool for data scientists and machine learning engineers to streamline their workflows and ensure reproducibility. By following these steps and harnessing the full potential of MLflow, you can bring your machine learning projects to life with confidence and efficiency. Stay tuned for more articles on mastering the art of machine learning with MLflow!
